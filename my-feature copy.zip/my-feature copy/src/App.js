import logo from './logo.svg';
import TopNodesTable from './TopNodes';
import './App.css';

function App() {
  return (
    <div className="App">
      <TopNodesTable /> {/* Using TopNodesTable component */}
    </div>
  );
}

export default App;
